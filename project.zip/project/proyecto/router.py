from aplicacion.viewsets import administradoresViewset
from aplicacion.viewsets import enfermerosViewset
from aplicacion.viewsets import familiarViewset
from aplicacion.viewsets import ingresoViewset
from aplicacion.viewsets import medicosViewset
from aplicacion.viewsets import pacientesViewset
from aplicacion.viewsets import signosvitalesViewset
from rest_framework import routers

router=routers.DefaultRouter()
router.register('administradores',administradoresViewset)
router.register('enfermeros',enfermerosViewset)
router.register('familiar',familiarViewset)
router.register('ingreso',ingresoViewset)
router.register('medicos',medicosViewset)
router.register('pacientes',pacientesViewset)
router.register('signosvitales',signosvitalesViewset)