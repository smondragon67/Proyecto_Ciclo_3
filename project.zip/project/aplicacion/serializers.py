from rest_framework import serializers
from .models import administradores
from .models import enfermeros
from .models import familiar
from .models import ingreso
from .models import medicos
from .models import pacientes
from .models import signosvitales

class administradoresSerializer(serializers.ModelSerializer):
    class Meta:
        model=administradores
        fields='__all__'

class enfermerosSerializer(serializers.ModelSerializer):
    class Meta:
        model=enfermeros
        fields='__all__'

class familiarSerializer(serializers.ModelSerializer):
    class Meta:
        model=familiar
        fields='__all__'

class ingresoSerializer(serializers.ModelSerializer):
    class Meta:
        model=ingreso
        fields='__all__'


class medicosSerializer(serializers.ModelSerializer):
    class Meta:
        model=medicos
        fields='__all__'

class pacientesSerializer(serializers.ModelSerializer):
    class Meta:
        model=pacientes
        fields='__all__'

class signosvitalesSerializer(serializers.ModelSerializer):
    class Meta:
        model=signosvitales
        fields='__all__'