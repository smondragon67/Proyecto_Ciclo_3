from rest_framework import viewsets
from . import models
from . import serializers

class administradoresViewset(viewsets.ModelViewSet):
    queryset=models.administradores.objects.all()
    serializer_class=serializers.administradoresSerializer

class enfermerosViewset(viewsets.ModelViewSet):
    queryset=models.enfermeros.objects.all()
    serializer_class=serializers.enfermerosSerializer

class familiarViewset(viewsets.ModelViewSet):
    queryset=models.familiar.objects.all()
    serializer_class=serializers.familiarSerializer

class ingresoViewset(viewsets.ModelViewSet):
    queryset=models.ingreso.objects.all()
    serializer_class=serializers.ingresoSerializer

class medicosViewset(viewsets.ModelViewSet):
    queryset=models.medicos.objects.all()
    serializer_class=serializers.medicosSerializer

class pacientesViewset(viewsets.ModelViewSet):
    queryset=models.pacientes.objects.all()
    serializer_class=serializers.pacientesSerializer

class signosvitalesViewset(viewsets.ModelViewSet):
    queryset=models.signosvitales.objects.all()
    serializer_class=serializers.signosvitalesSerializer