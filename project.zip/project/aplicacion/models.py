from django.db import models

class ingreso(models.Model):
    IdIngreso=models.BigAutoField(primary_key=True)
    usuario=models.CharField(max_length=50)
    contraseña=models.CharField(max_length=50)

class administradores(models.Model):
    IdAdministradores=models.BigAutoField(primary_key=True)
    Nombresadministradores=models.CharField(max_length=50)
    Apellidosadministradores=models.CharField(max_length=50)
    Idingreso=models.ForeignKey(ingreso,on_delete=models.SET_NULL, null=True)

class enfermeros(models.Model):
    IdEnfermeros=models.BigAutoField(primary_key=True)
    NombresEnfermero=models.CharField(max_length=50)
    ApellidosEnfermero=models.CharField(max_length=50)
    Idingreso=models.ForeignKey(ingreso,on_delete=models.SET_NULL, null=True)

class familiar(models.Model):
    IdFamiliar=models.BigAutoField(primary_key=True,)
    NombresFamiliar=models.CharField(max_length=50)
    ApellidosFamiliar=models.CharField(max_length=50)
    CedulaFamiliar=models.CharField(max_length=50)
    DireccionFamiliar=models.CharField(max_length=50)
    TelefonoFamiliar=models.CharField(max_length=50)
    CorreoFamiliar=models.CharField(max_length=50)
    Idingreso=models.ForeignKey(ingreso,on_delete=models.SET_NULL, null=True)


class medicos(models.Model):
    IdMedicos=models.BigAutoField(primary_key=True)
    NombresMedico=models.CharField(max_length=50)
    ApellidosMedico=models.CharField(max_length=50)
    Especialidad=models.CharField(max_length=50)
    Idingreso=models.ForeignKey(ingreso,on_delete=models.SET_NULL, null=True)

class pacientes(models.Model):
    IdPacientes=models.BigAutoField(primary_key=True)
    NombresPaciente=models.CharField(max_length=50)
    ApellidosPaciente=models.CharField(max_length=50)
    CedulaPaciente=models.CharField(max_length=50)
    DireccionPaciente=models.CharField(max_length=50)
    TelefonoPaciente=models.CharField(max_length=50)
    CorreoPaciente=models.CharField(max_length=50)
    CoordemadasPaciente=models.CharField(max_length=50)
    Idingreso=models.ForeignKey(ingreso,on_delete=models.SET_NULL, null=True)
    Idingreso=models.ForeignKey(medicos,on_delete=models.SET_NULL, null=True)
    Idingreso=models.ForeignKey(enfermeros,on_delete=models.SET_NULL, null=True)
    Idingreso=models.ForeignKey(familiar,on_delete=models.SET_NULL, null=True)
    Idingreso=models.ForeignKey(administradores,on_delete=models.SET_NULL, null=True)

class signosvitales(models.Model):
    IdSignosVItales=models.BigAutoField(primary_key=True)
    FechaRegistro=models.CharField(max_length=50)
    Oximetria=models.CharField(max_length=50)
    FrecuenciaRespiratoria=models.CharField(max_length=50)
    FrecuenciaCardiaca=models.CharField(max_length=50)
    Temperatura=models.CharField(max_length=50)
    PresionArterial=models.CharField(max_length=50)
    Glicemas=models.CharField(max_length=50)
    Diagnostico=models.CharField(max_length=50)
    Sugerencia=models.CharField(max_length=50)
    Idpacientes=models.ForeignKey(pacientes,on_delete=models.SET_NULL, null=True)

# Create your models here.
